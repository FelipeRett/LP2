namespace PVolume
{
    public partial class Form1 : Form
    {
        Double raio, altura, volume;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio) || (raio <= 0))
            {
                MessageBox.Show("Raio inv�lido");
                txtRaio.Focus();
                txtRaio.Clear();
            }
            else if (!Double.TryParse(txtAltura.Text, out altura) || (altura <= 0))
            {
                MessageBox.Show("Altura inv�lida");
                txtAltura.Focus();
                txtAltura.Clear();
            }
            else
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura;
                txtVolume.Text = volume.ToString("N2");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtRaio_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio) || (raio <= 0))
            {
                MessageBox.Show("Raio inv�lido");
            }

            // Se eu quisesse validar o raio de outra forma 
            /* else if(raio <= 0)
            {
                MessageBox.Show("Raio deve ser maior que zero");
            } */

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text = "";
            txtRaio.Text = String.Empty;
            txtVolume.Clear();
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura) || (altura <= 0))
            {
                MessageBox.Show("Altura inv�lida");
            }
        }
    }
}
