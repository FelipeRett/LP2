﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            lblValorA = new Label();
            lblValorC = new Label();
            lblValorB = new Label();
            txtValorA = new TextBox();
            txtValorB = new TextBox();
            txtValorC = new TextBox();
            btnCalcular = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            errorProvider1 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // lblValorA
            // 
            lblValorA.AutoSize = true;
            lblValorA.Location = new Point(80, 44);
            lblValorA.Name = "lblValorA";
            lblValorA.Size = new Size(69, 25);
            lblValorA.TabIndex = 0;
            lblValorA.Text = "Valor A";
            // 
            // lblValorC
            // 
            lblValorC.AutoSize = true;
            lblValorC.Location = new Point(76, 170);
            lblValorC.Name = "lblValorC";
            lblValorC.Size = new Size(73, 25);
            lblValorC.TabIndex = 1;
            lblValorC.Text = " Valor C";
            // 
            // lblValorB
            // 
            lblValorB.AutoSize = true;
            lblValorB.Location = new Point(80, 104);
            lblValorB.Name = "lblValorB";
            lblValorB.Size = new Size(67, 25);
            lblValorB.TabIndex = 2;
            lblValorB.Text = "Valor B";
            // 
            // txtValorA
            // 
            txtValorA.Location = new Point(211, 44);
            txtValorA.Name = "txtValorA";
            txtValorA.Size = new Size(150, 31);
            txtValorA.TabIndex = 4;
            txtValorA.Validated += txtValorA_Validated;
            // 
            // txtValorB
            // 
            txtValorB.Location = new Point(211, 104);
            txtValorB.Name = "txtValorB";
            txtValorB.Size = new Size(150, 31);
            txtValorB.TabIndex = 5;
            txtValorB.Validated += txtValorB_Validated;
            // 
            // txtValorC
            // 
            txtValorC.Location = new Point(211, 170);
            txtValorC.Name = "txtValorC";
            txtValorC.Size = new Size(150, 31);
            txtValorC.TabIndex = 6;
            txtValorC.Validated += txtValorC_Validated;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(35, 248);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(112, 34);
            btnCalcular.TabIndex = 8;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += button1_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(194, 248);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(112, 34);
            btnLimpar.TabIndex = 9;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(350, 248);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(112, 34);
            btnSair.TabIndex = 10;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(992, 623);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(txtValorC);
            Controls.Add(txtValorB);
            Controls.Add(txtValorA);
            Controls.Add(lblValorB);
            Controls.Add(lblValorC);
            Controls.Add(lblValorA);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblValorA;
        private Label lblValorC;
        private Label lblValorB;
        private TextBox txtValorA;
        private TextBox txtValorB;
        private TextBox txtValorC;
        private Button btnCalcular;
        private Button btnLimpar;
        private Button btnSair;
        private ErrorProvider errorProvider1;
    }
}
