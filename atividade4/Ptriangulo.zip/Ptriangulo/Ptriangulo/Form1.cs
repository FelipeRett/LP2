namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((ladoA > Math.Abs(ladoB - ladoC)) && (ladoA < ladoB + ladoC) && (ladoB > Math.Abs(ladoA - ladoC)) && (ladoB < ladoA + ladoB) && (ladoC > Math.Abs(ladoA - ladoB)) && (ladoC < ladoA + ladoB))
            {
                if (ladoA == ladoB && ladoA == ladoC)
                {
                    MessageBox.Show("Tri�ngulo equil�tero");

                }
                else if (ladoA == ladoB || ladoC == ladoA || ladoB == ladoC)
                {
                    MessageBox.Show("Tri�ngulo is�sceles");
                }
                else
                {
                    MessageBox.Show("Tri�ngulo Escaleno");
                }
            }
            else
            {
                MessageBox.Show("N�o � triangulo");
            }
        }

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.SetError(txtValorA, "");
                ladoA = Convert.ToDouble(txtValorA.Text);
            }
            catch
            {
                errorProvider1.SetError(txtValorA, "N�mero inv�lido");
                txtValorA.Focus();
            }
        }

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.SetError(txtValorB, "");
                ladoB = Convert.ToDouble(txtValorB.Text);
            }
            catch
            {
                errorProvider1.SetError(txtValorB, "N�mero inv�lido");
                txtValorB.Focus();
            }
        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.SetError(txtValorC, "");
                ladoC = Convert.ToDouble(txtValorC.Text);
            }
            catch
            {
                errorProvider1.SetError(txtValorC, "N�mero inv�lido");
                txtValorC.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
