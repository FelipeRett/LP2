﻿namespace Pcalc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            lblNumero1 = new Label();
            lblResultado = new Label();
            lblNumero2 = new Label();
            txtNumero1 = new TextBox();
            txtNumero2 = new TextBox();
            txtResultado = new TextBox();
            btnAdd = new Button();
            btnSub = new Button();
            btnMult = new Button();
            btnDiv = new Button();
            btnSair = new Button();
            btnLimpar = new Button();
            errorProvider1 = new ErrorProvider(components);
            errorProvider2 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).BeginInit();
            SuspendLayout();
            // 
            // lblNumero1
            // 
            lblNumero1.AutoSize = true;
            lblNumero1.Location = new Point(190, 90);
            lblNumero1.Name = "lblNumero1";
            lblNumero1.Size = new Size(92, 25);
            lblNumero1.TabIndex = 0;
            lblNumero1.Text = "Numero 1";
            lblNumero1.Click += label1_Click;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(190, 253);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(90, 25);
            lblResultado.TabIndex = 1;
            lblResultado.Text = "Resultado";
            lblResultado.Click += label2_Click;
            // 
            // lblNumero2
            // 
            lblNumero2.AutoSize = true;
            lblNumero2.Location = new Point(190, 173);
            lblNumero2.Name = "lblNumero2";
            lblNumero2.Size = new Size(92, 25);
            lblNumero2.TabIndex = 2;
            lblNumero2.Text = "Numero 2";
            // 
            // txtNumero1
            // 
            txtNumero1.Location = new Point(312, 87);
            txtNumero1.Name = "txtNumero1";
            txtNumero1.Size = new Size(253, 31);
            txtNumero1.TabIndex = 3;
            txtNumero1.TextChanged += textBox1_TextChanged;
            txtNumero1.Validated += txtNumero1_Validated;
            // 
            // txtNumero2
            // 
            txtNumero2.Location = new Point(312, 170);
            txtNumero2.Name = "txtNumero2";
            txtNumero2.Size = new Size(253, 31);
            txtNumero2.TabIndex = 4;
            txtNumero2.Validated += txtNumero2_Validated;
            // 
            // txtResultado
            // 
            txtResultado.Enabled = false;
            txtResultado.Location = new Point(312, 253);
            txtResultado.Name = "txtResultado";
            txtResultado.Size = new Size(253, 31);
            txtResultado.TabIndex = 5;
            txtResultado.TextChanged += txtResultado_TextChanged;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(219, 321);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(44, 34);
            btnAdd.TabIndex = 6;
            btnAdd.Text = "+";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnSub
            // 
            btnSub.Location = new Point(312, 321);
            btnSub.Name = "btnSub";
            btnSub.Size = new Size(44, 34);
            btnSub.TabIndex = 7;
            btnSub.Text = "-";
            btnSub.UseVisualStyleBackColor = true;
            btnSub.Click += btnSub_Click;
            // 
            // btnMult
            // 
            btnMult.Location = new Point(412, 321);
            btnMult.Name = "btnMult";
            btnMult.Size = new Size(44, 34);
            btnMult.TabIndex = 8;
            btnMult.Text = "*";
            btnMult.UseVisualStyleBackColor = true;
            btnMult.Click += button3_Click;
            // 
            // btnDiv
            // 
            btnDiv.Location = new Point(504, 321);
            btnDiv.Name = "btnDiv";
            btnDiv.Size = new Size(44, 34);
            btnDiv.TabIndex = 9;
            btnDiv.Text = "/";
            btnDiv.UseVisualStyleBackColor = true;
            btnDiv.Click += btnDiv_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(600, 311);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(99, 43);
            btnSair.TabIndex = 10;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(600, 225);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(99, 43);
            btnLimpar.TabIndex = 11;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            errorProvider2.ContainerControl = this;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1254, 678);
            Controls.Add(btnLimpar);
            Controls.Add(btnSair);
            Controls.Add(btnDiv);
            Controls.Add(btnMult);
            Controls.Add(btnSub);
            Controls.Add(btnAdd);
            Controls.Add(txtResultado);
            Controls.Add(txtNumero2);
            Controls.Add(txtNumero1);
            Controls.Add(lblNumero2);
            Controls.Add(lblResultado);
            Controls.Add(lblNumero1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNumero1;
        private Label lblResultado;
        private Label lblNumero2;
        private TextBox txtNumero1;
        private TextBox txtNumero2;
        private TextBox txtResultado;
        private Button btnAdd;
        private Button btnSub;
        private Button btnMult;
        private Button btnDiv;
        private Button btnSair;
        private Button btnLimpar;
        private ErrorProvider errorProvider1;
        private ErrorProvider errorProvider2;
    }
}
