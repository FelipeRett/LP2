namespace Pcalc
{
    public partial class Form1 : Form

    {
        double numero1, numero2, resultado; // globais
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString("G");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voc� deseja sair mesmo?", "Sa�da", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
            
            
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString("G");

        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero1.Text, out numero1))
            {
                errorProvider1.SetError(txtNumero1, "Numero 1 inv�lido");
                txtNumero1.Focus();
            }
            else
                errorProvider1.SetError(txtNumero1, "");

        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtNumero2, "");
                numero2 = Convert.ToDouble(txtNumero2.Text);
            }
            catch
            {
                errorProvider2.SetError(txtNumero2, "Numero 2 inv�lido");
                txtNumero2.Focus();
            }
        }

        private void txtResultado_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultado.Text = resultado.ToString("G");
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 != 0)
            {
                resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString("G");
            }
            else
            {
                MessageBox.Show("N�mero 2 tem que ser maior que 0");
                txtNumero2.Focus();
                txtNumero2.Clear();
            }


        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear(); 
            txtNumero2.Clear();
            txtResultado.Clear();
        }
    }
}
