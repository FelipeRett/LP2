﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {

        double altura, peso, imc;

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.SetError(txtAltura, "");
                altura = Convert.ToDouble(txtAltura.Text);
                /*if (altura <= 0)
                {
                    txtAltura.Focus();
                }*/
            }
            catch
            {
                errorProvider1.SetError(txtAltura, "Peso invalido");
                txtAltura.Focus();
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (peso != 0 && altura != 0)
            {
                imc = peso / Math.Pow(altura, 2);
                imc = Math.Round(imc, 1);
                txtImc.Text = imc.ToString();


                if ( imc < 18.5)
                {
                    MessageBox.Show("MAGREZA");
                }
                else if (imc <= 24.9)
                {
                    MessageBox.Show("NORMAL");
                }
                else if (imc <= 29.9)
                {
                    MessageBox.Show("SOBREPESO");
                }
                else if (imc <= 39.9)
                {
                    MessageBox.Show("OBESIDADE");
                }
                else
                {
                    MessageBox.Show("OBESIDADE GRAVE");
                }

         
            }
            else
            {
                MessageBox.Show("Digite um valor maior que 0");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();
            txtImc.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.SetError(txtPeso, "");
                peso = Convert.ToDouble(txtPeso.Text);
                /*if (peso <= 0)
                {
                    txtPeso.Focus();
                }*/
            }
            catch
            {
                errorProvider1.SetError(txtPeso, "Peso invalido");
                txtPeso.Focus();
            }
        }
    }
}
